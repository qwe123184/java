package com.fenglin.springboottest.common;

import java.io.Serializable;

/**
 * 登录请求
 */
public class LoginRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 守夜人代号（登录名） */
    private String username;

    /** 禁墟密钥（明文） */
    private String password;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
